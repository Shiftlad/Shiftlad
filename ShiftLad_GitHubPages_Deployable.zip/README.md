# ShiftLad
GitHub Pages deployment of the ShiftLad time tracking app.
